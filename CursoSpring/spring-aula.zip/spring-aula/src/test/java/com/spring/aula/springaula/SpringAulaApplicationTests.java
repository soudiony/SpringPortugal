package com.spring.aula.springaula;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAulaApplicationTests {

	@Test
	void contextLoads() {
	}

}
